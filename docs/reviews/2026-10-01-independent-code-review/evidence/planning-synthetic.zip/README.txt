OpenPlan project evidence bundle

Project ID: 44444444-4444-4444-8444-444444444444
Generated: 2026-10-01T12:00:00.000Z

This retained snapshot is not an approval, adoption, publication, or backup.
Read manifest.json before relying on a file. It records excluded evidence, missing metadata, custody, uncertainty, and known limits.
Run `sha256sum -c checksums.sha256` from this directory to verify the packaged files.
Open project/project.gpkg with an OGC GeoPackage reader such as ogrinfo or QGIS.
