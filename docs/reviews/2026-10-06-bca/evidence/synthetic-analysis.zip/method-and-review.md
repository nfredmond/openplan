# Synthetic example: corridor travel time

Calculation status: review-required. Responsible analyst review and program acceptance are not established by this calculation.

Project: cd275071-340a-4928-a6fa-f7f25bf0f8bc
Program: USDOT discretionary grants, 2026 method
Edition: USDOT December 2025 / 2026 update
Method source: https://www.transportation.gov/sites/dot.gov/files/2025-12/Benefit%20Cost%20Analysis%20Guidance%202026%20Update%20%28Final%29.pdf
Controlling program: Verify the current notice
Standalone BCA narrative and unlocked calculation workbook.
Full project capital costs, regardless of funding source; incremental No Build comparison.
O&M changes and residual value in the BCR numerator; upfront capital in the denominator.
Show physical effects that are not monetized separately.
Applicability: Training example only. No application eligibility is asserted.

## Scope
Synthetic corridor
No Build: Synthetic No Build case with 100,000 annual person-hours.
Build: Synthetic Build case with reduced person-hours. No real project or traffic observation.

## Method
Annual Build/No Build differences in constant 2024 dollars. End-of-year discounting to 2026.
Dollar year 2024; discount epoch 2026; real rate 7%; analysis 2026 to 2047; opens 2028.
Reduction benefits = (No Build minus Build) × annualization × unit value × dollar conversion. Increase benefits, including residual value, use Build minus No Build. Costs reverse the quantity difference. Annual overrides replace the base quantities and unit value for that year. Growth applies only in years without an override. All flows occur at year end; the discount epoch has exponent zero.
BCR uses capital in the denominator. Net operating/rehabilitation costs reduce the numerator. Residual is entered as a final-year benefit.

## Results
BCR: 1.594
Net present value: $1,188,105
Present-value numerator: $3,188,105
Present-value denominator: $2,000,000


## Project elements
Allocate shared costs and effects once. Element ratios are not additive.
Whole project: BCR 1.594; NPV $1,188,105; 3 open checks.

## Sensitivity
Illustrative stress ranges. Replace with project-specific evidence; these are not confidence bounds.
These scenarios are assumptions, not confidence intervals.
Base case: BCR 1.594; NPV $1,188,105. 
Lower benefits: BCR 1.270; NPV $540,583. 
Higher benefits: BCR 1.918; NPV $1,835,627. 
Lower costs: BCR 1.774; NPV $1,393,056. 
Higher costs: BCR 1.220; NPV $573,254. 
Lower benefits and higher costs: BCR 0.971; NPV -$74,268. 
3% discount rate: BCR 2.326; NPV $2,651,016. 

## Review worklist
- review: Capital cost: Synthetic training assumptions is assumption or lacks a reference, locator or method.
- review: Travel time: Synthetic training assumptions is assumption or lacks a reference, locator or method.
- review: Incremental maintenance: Synthetic training assumptions is assumption or lacks a reference, locator or method.

## Benefits not monetized
None recorded. This does not establish that none exist.

## Exclusions
Synthetic example excludes safety, emissions, induced demand and residual value.

## Analyst review
Not recorded. No approval is inferred.

## Sources
- example: Synthetic training assumptions. OpenPlan synthetic example, Training example, no observed data. Status: assumption. Method: Illustrative inputs for inspecting arithmetic. Limitation: Not a real project. Do not submit.. Owner: unassigned; due: unset.

## Reuse
OpenPlan supporting analysis. This is not a native Cal-B/C workbook and does not execute its macros. Review required program forms separately. The XLSX has editable annual inputs and formulas; source/review checks are a snapshot and do not refresh when Excel inputs change. Return changes to OpenPlan for a new review and retained version.
